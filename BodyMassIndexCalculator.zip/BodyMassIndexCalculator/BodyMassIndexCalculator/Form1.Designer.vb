﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblWeight = New System.Windows.Forms.Label()
        Me.lblHeight = New System.Windows.Forms.Label()
        Me.lblIndex = New System.Windows.Forms.Label()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.txtWeight = New System.Windows.Forms.TextBox()
        Me.txtHeight = New System.Windows.Forms.TextBox()
        Me.txtIndex = New System.Windows.Forms.TextBox()
        Me.txtStatus = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.lbxChart = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'lblWeight
        '
        Me.lblWeight.AutoSize = True
        Me.lblWeight.Location = New System.Drawing.Point(16, 22)
        Me.lblWeight.Name = "lblWeight"
        Me.lblWeight.Size = New System.Drawing.Size(156, 17)
        Me.lblWeight.TabIndex = 0
        Me.lblWeight.Text = "Enter weight in pounds:"
        '
        'lblHeight
        '
        Me.lblHeight.AutoSize = True
        Me.lblHeight.Location = New System.Drawing.Point(16, 63)
        Me.lblHeight.Name = "lblHeight"
        Me.lblHeight.Size = New System.Drawing.Size(149, 17)
        Me.lblHeight.TabIndex = 1
        Me.lblHeight.Text = "Enter height in inches:"
        '
        'lblIndex
        '
        Me.lblIndex.AutoSize = True
        Me.lblIndex.Location = New System.Drawing.Point(16, 101)
        Me.lblIndex.Name = "lblIndex"
        Me.lblIndex.Size = New System.Drawing.Size(118, 17)
        Me.lblIndex.TabIndex = 2
        Me.lblIndex.Text = "Body Mass Index:"
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Location = New System.Drawing.Point(16, 141)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(100, 17)
        Me.lblStatus.TabIndex = 3
        Me.lblStatus.Text = "Weight Status:"
        '
        'txtWeight
        '
        Me.txtWeight.Location = New System.Drawing.Point(178, 19)
        Me.txtWeight.Name = "txtWeight"
        Me.txtWeight.Size = New System.Drawing.Size(100, 22)
        Me.txtWeight.TabIndex = 4
        '
        'txtHeight
        '
        Me.txtHeight.Location = New System.Drawing.Point(178, 60)
        Me.txtHeight.Name = "txtHeight"
        Me.txtHeight.Size = New System.Drawing.Size(100, 22)
        Me.txtHeight.TabIndex = 5
        '
        'txtIndex
        '
        Me.txtIndex.Location = New System.Drawing.Point(178, 98)
        Me.txtIndex.Name = "txtIndex"
        Me.txtIndex.ReadOnly = True
        Me.txtIndex.Size = New System.Drawing.Size(100, 22)
        Me.txtIndex.TabIndex = 6
        '
        'txtStatus
        '
        Me.txtStatus.Location = New System.Drawing.Point(122, 138)
        Me.txtStatus.Name = "txtStatus"
        Me.txtStatus.ReadOnly = True
        Me.txtStatus.Size = New System.Drawing.Size(156, 22)
        Me.txtStatus.TabIndex = 7
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(321, 18)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(285, 42)
        Me.btnCalculate.TabIndex = 8
        Me.btnCalculate.Text = "Calculate BMI"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'lbxChart
        '
        Me.lbxChart.FormattingEnabled = True
        Me.lbxChart.ItemHeight = 16
        Me.lbxChart.Location = New System.Drawing.Point(321, 68)
        Me.lbxChart.Name = "lbxChart"
        Me.lbxChart.Size = New System.Drawing.Size(285, 164)
        Me.lbxChart.TabIndex = 9
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(664, 244)
        Me.Controls.Add(Me.lbxChart)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtStatus)
        Me.Controls.Add(Me.txtIndex)
        Me.Controls.Add(Me.txtHeight)
        Me.Controls.Add(Me.txtWeight)
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.lblIndex)
        Me.Controls.Add(Me.lblHeight)
        Me.Controls.Add(Me.lblWeight)
        Me.Name = "Form1"
        Me.Text = "Body Mass Index Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblWeight As Label
    Friend WithEvents lblHeight As Label
    Friend WithEvents lblIndex As Label
    Friend WithEvents lblStatus As Label
    Friend WithEvents txtWeight As TextBox
    Friend WithEvents txtHeight As TextBox
    Friend WithEvents txtIndex As TextBox
    Friend WithEvents txtStatus As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents lbxChart As ListBox
End Class
